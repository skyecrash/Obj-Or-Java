/**
 * A class to represent the Schedule type.
 * @author Lilith Freed
 */
public class Schedule extends DoubleLinkedList<ScheduleSlot> {
  ;
}